#pragma once

#include "ggml-cpu-traits.h"
#include "ggml.h"

// GGML internal header

lm_ggml_backend_buffer_type_t lm_ggml_backend_cpu_aarch64_buffer_type(void);
